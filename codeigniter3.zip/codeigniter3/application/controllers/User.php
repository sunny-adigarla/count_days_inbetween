<?php
/**
 * This class shows user registration form.
 * It takes input of 'Start Date' and 'End Date' from user using registration form.
 * It shows number of days between the 'Start Date' and 'End Date' as per calendar to user.
 */
class User extends CI_Controller
{
	public function index()
	{
		$data['title'] = 'User';
		$this->load->view('templates/header');
		$this->load->view("user/index", $data);
		$this->load->view('templates/footer');
	}

	public function registration()
	{
		$data['title'] = 'Registration';

		// Form validation
		$this->form_validation->set_rules('startDate', 'Start Date', 'required');
		$this->form_validation->set_rules('endDate', 'End Date', 'required');

		// Get number of days between 'Start Date' and 'End Date'
		if ($this->form_validation->run() === FALSE) {
			$data['noOfDays'] = 0;
		} else {
			$data['noOfDays'] = $this->days_model->getNoOfDays();
		}

		// Pass user input
		$data['startDate'] = $this->input->post('startDate');
		$data['endDate'] = $this->input->post('endDate');

		$this->load->view('templates/header');
		$this->load->view("user/registration", $data);
		$this->load->view('templates/footer');
	}
}