<h2><?php echo $title; ?></h2>
<p>Welcome to the HRMS application</p>