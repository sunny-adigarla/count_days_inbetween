<html>
<head>
	<title>HRMS</title>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" />
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/hrms.css" />
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="navbar-brand">HRMS</div>
        <div class="collapse navbar-collapse" id="navbarColor01">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url(); ?>">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url(); ?>user/registration">Registration</a>
            </li>
          </ul>
        </div>
  </nav>
  <div class="page-margin">
