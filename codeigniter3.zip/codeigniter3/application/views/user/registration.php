<h2><?php echo $title; ?></h2>
<?php echo validation_errors(); ?>
<?php echo form_open('user/registration'); ?>
  <div class="form-group">
    <label>Start Date</label>
    <input type="date" class="form-control" name="startDate" value="<?php echo $startDate; ?>" />
  </div>
  <div class="form-group">
    <label>End Date</label>
    <input type="date" class="form-control" name="endDate" value="<?php echo $endDate; ?>" />
  </div>
  <p>No of days between the above two dates is <?php echo $noOfDays; ?></p>
  <button type="submit" class="btn btn-default">Submit</button>
</form>