<?php
class Days_model extends CI_Model
{
	/**
	 * Day of Start Date
	 * @access public
	 */
	public $start_day;
	/**
	 * Month of Start Date
	 * @access public
	 */
	public $start_month;
	/**
	 * Year of Start Date
	 * @access public
	 */
	public $start_year;
	/**
	 * Day of End Date
	 * @access public
	 */
	public $end_day;
	/**
	 * Month of End Date
	 * @access public
	 */
	public $end_month;
	/**
	 * Month of End Date
	 * @access public
	 */
	public $end_year;

	/**
	 * This method calculates number of days between months of 'Start Date' and 'End Date'
	 * @access public
	 * @param $start_day int  An integer of 'Start Date's day
	 * @param $start_month int  An integer of 'Start Date's month
	 * @param $end_day int  An integer of 'End Date's day
	 * @param $end_month int  An integer of 'End Date's month
	 * @return $total_days int  An integer of number of days between months of 'Start Date' and 'End Date'
	 */
	public function getDaysOfMonths($start_day, $start_month, $end_day, $end_month)
	{
		$total_days = 0;
		$days_of_months = array(0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
		foreach ($days_of_months as $month => $days) {
			if ($start_month <= $month && $end_month >= $month) {
				if ($start_month == $month) {
					$days -= $start_day;
				} elseif ($end_month == $month) {
					$days = $end_day - 1;
				}
				$total_days += $days;
			}
		}
		return $total_days;
	}

	/**
	 * This method checks whether the given year is leap year or not.
	 * @access public
	 * @param $year int  An integer of year.
	 * @return boolean  A boolean value true if the given $year is a leap year else false.
	 */
	public function isLeapYear($year)
	{
		if ($year%100 == 0) {
			if ($year%400 == 0) {
				return true;
			}
		} else if ($year%4 == 0) {
			return true;
		}
		return false;
	}

	/**
	 * This method checks whether a leap day exists or not in the 'Start Date' or 'End Date' year and falls in  * the duration.
	 * @access public
	 * @return $leap_day int  An integer of value 1 if a leap exists in the 'Start Date' or 'End Date' year and  * falls in the duration else 0.
	 */
	public function leapDayExist()
	{
		$leap_day_exist = ($this->isLeapYear($this->start_year) && ($this->start_month <= 2)) ||
			     		 ($this->isLeapYear($this->end_year) && 
			     		 	(($this->end_month > 2) || (($this->end_month == 2) && $this->end_day == 29))
			  	 		 );
		$leap_day = $leap_day_exist ? 1 : 0;
		return $leap_day;		
	}

	/**
	 * This method calculates number of days in between when 'Start Date' and 'End Date' have same year.
	 * @return $total_days int  An integer of number of days between months of the same year.
	 */
	public function sameYear()
	{
		if ($this->start_month == $this->end_month) {
			$total_days = ($this->end_day - $this->start_day) - 1;
		} else {
			$total_days = $this->getDaysOfMonths($this->start_day, $this->start_month, $this->end_day, $this->end_month);
		}
		return $total_days + $this->leapDayExist();
	}

	/**
	 * This method calculates number of days in between when 'Start Date' and 'End Date' have consecutive years.
	 * @return $total_days int  An integer of sum of days of 'Start Date' year days, 'End Date' year days and    * leap year days.
	 */
	public function consecutiveYears()
	{
		$days_of_start_year = $this->getDaysOfMonths($this->start_day, $this->start_month, 32, 12);
		$days_of_end_year = $this->getDaysOfMonths(0, 1, $this->end_day, $this->end_month);
		$total_days = $days_of_start_year + $days_of_end_year + $this->leapDayExist();
		return $total_days;
	}

	/**
	 * This method calculates number of leap years in between 'Start Date' and 'End Date'.
	 * @access public
	 * @return $leap_years int  An integer of leap years in between 'Start Date' and 'End Date'.
	 */
	public function getLeapYears()
	{
		$leap_years = 0;
		for ($i = ($this->start_year + 1); $i < $this->end_year; $i++) {
			if ($this->isLeapYear($i)) {
				$leap_years++;
			}
		}
		return $leap_years;
	}

	/**
	 * This method calculates number of days of multiple years in between 'Start Date' and 'End Date'.
	 * @access public
	 * @return $total_days int  A sum of number of days of start and end years, middle years and leap days.
	 */
	public function multipleYears()
	{
		$days_start_end_years = $this->consecutiveYears();
		$days_of_middle_years = ($this->end_year - $this->start_year - 1) * 365;
		$leap_years = $this->getLeapYears();
		$total_days = $days_start_end_years + $days_of_middle_years + $leap_years;
		return $total_days;
	}

	/**
	 * This method calculates number of days between 'Start Date' and 'End Date'.
	 * @access public
	 * @return $no_of_days int  An integer of number of days between 'Start Date' and 'End Date'.
	 */
	public function getNoOfDays()
	{
		// Take user input
		$start_date = $this->input->post('startDate');
		$end_date = $this->input->post('endDate');

		// Get day, month and year from 'Start Date'
		$start_date_array = explode('-', $start_date);
		$this->start_day = $start_date_array[2];
		$this->start_month = $start_date_array[1];
		$this->start_year = $start_date_array[0];

		// Get day, month and year from 'End Date'
		$end_date_array = explode('-', $end_date);
		$this->end_day = $end_date_array[2];
		$this->end_month = $end_date_array[1];
		$this->end_year = $end_date_array[0];

		// Get number of years between 'Start Date' and 'End Date'
		$difference_of_years = $this->end_year - $this->start_year;

		// Call methods based on case
		switch ($difference_of_years) {
			case 0:		$no_of_days = $this->sameYear();
						break;
			case 1: 	$no_of_days = $this->consecutiveYears();
						break;
			default: 	$no_of_days = $this->multipleYears();
					 	break;
		}
		return $no_of_days;
	}
}